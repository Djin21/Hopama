<div class="pt-4 d-none" id="chartPatientConsulter1" style="width: 100%;"></div>
<div class="pt-4" id="chartPatientConsulter2" style="width: 100%;"></div>

