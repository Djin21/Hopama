
    <x-listComponent id='first' name="valeur" :exam="$services[0]->nom"/>